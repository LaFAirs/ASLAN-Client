package gg.vyra.client.mixin;

import gg.vyra.client.menu.VyraMainMenu;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Ersetzt den Vanilla-Titelbildschirm durch das VYRA-Hauptmenü.
 * Einmalig pro Sitzung (Flag), damit Untermenüs normal funktionieren.
 */
@Mixin(class_442.class)
public abstract class TitleScreenMixin extends class_437 {
    protected TitleScreenMixin(net.minecraft.class_2561 title) {
        super(title);
    }

    private static boolean vyraShown = false;

    @Inject(method = "init", at = @At("HEAD"))
    private void vyra$replaceTitle(CallbackInfo ci) {
        if (vyraShown) return;
        vyraShown = true;
        class_310 mc = class_310.method_1551();
        if (mc != null) mc.method_1507(new VyraMainMenu());
    }
}
