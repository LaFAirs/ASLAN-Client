package gg.vyra.client.menu;

import gg.vyra.client.VyraClient;
import gg.vyra.client.core.HudLayout;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** Ingame-HUD-Editor: Profilwahl, Widget-Toggles, Raster-Snap. */
public final class HudEditorScreen extends class_437 {
    private final class_437 parent;

    public HudEditorScreen(class_437 parent) {
        super(class_2561.method_43470("VYRA HUD-Editor"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int y = 40;
        method_37063(btn(20, y, "Profil: PvP", b -> VyraClient.hud().setProfile("pvp")));
        method_37063(btn(180, y, "Profil: Survival", b -> VyraClient.hud().setProfile("survival")));
        method_37063(btn(340, y, "Raster-Snap", b -> VyraClient.hud().active().snapToGrid(0.02)));
        y += 30;
        HudLayout l = VyraClient.hud().active();
        int x = 20;
        for (HudLayout.Widget w : l.widgets) {
            final HudLayout.Widget fw = w;
            method_37063(btn(x, y, (fw.enabled ? "[x] " : "[ ] ") + fw.id, b -> {
                fw.enabled = !fw.enabled;
                b.method_25355(class_2561.method_43470((fw.enabled ? "[x] " : "[ ] ") + fw.id));
                VyraClient.hud().saveToDisk();
            }));
            x += 165;
            if (x > field_22789 - 170) { x = 20; y += 26; }
        }
        method_37063(btn(20, field_22790 - 40, "Fertig", b -> method_25419()));
    }

    private class_4185 btn(int x, int y, String label, class_4185.class_4241 a) {
        return class_4185.method_46430(class_2561.method_43470(label), a).method_46434(x, y, 150, 22).method_46431();
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        method_25420(ctx, mouseX, mouseY, delta);
        ctx.method_27534(field_22793, field_22785, field_22789 / 2, 12, 0xFFFFFF);
        super.method_25394(ctx, mouseX, mouseY, delta);
    }

    @Override
    public void method_25419() {
        if (field_22787 != null) field_22787.method_1507(parent);
    }
}
