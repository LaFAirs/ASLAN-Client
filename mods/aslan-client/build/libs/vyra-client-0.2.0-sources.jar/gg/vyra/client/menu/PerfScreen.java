package gg.vyra.client.menu;

import gg.vyra.client.VyraClient;
import gg.vyra.client.core.PerformanceEngine;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** Performance-Auswahl ingame (spiegelt Launcher-Profile). */
public final class PerfScreen extends class_437 {
    private final class_437 parent;

    public PerfScreen(class_437 parent) {
        super(class_2561.method_43470("VYRA Performance"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int y = 60;
        for (PerformanceEngine.Profile p : PerformanceEngine.Profile.values()) {
            final PerformanceEngine.Profile fp = p;
            method_37063(class_4185.method_46430(class_2561.method_43470("Profil: " + p.name()), b -> {
                VyraClient.perf().apply(fp);
            }).method_46434(field_22789 / 2 - 100, y, 200, 22).method_46431());
            y += 26;
        }
        method_37063(class_4185.method_46430(class_2561.method_43470("Benchmark: 10 s"), b -> {
            VyraClient.bench().start(10);
            b.method_25355(class_2561.method_43470("Benchmark läuft …"));
        }).method_46434(field_22789 / 2 - 100, y + 10, 200, 22).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Zurück"), b -> method_25419())
                .method_46434(field_22789 / 2 - 100, y + 38, 200, 22).method_46431());
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        method_25420(ctx, mouseX, mouseY, delta);
        ctx.method_27534(field_22793, field_22785, field_22789 / 2, 24, 0xFFFFFF);
        String s = VyraClient.bench().summary();
        if (s != null) ctx.method_27534(field_22793, class_2561.method_43470(s), field_22789 / 2, field_22790 - 60, 0x94A3B8);
        super.method_25394(ctx, mouseX, mouseY, delta);
    }

    @Override
    public void method_25419() {
        if (field_22787 != null) field_22787.method_1507(parent);
    }
}
