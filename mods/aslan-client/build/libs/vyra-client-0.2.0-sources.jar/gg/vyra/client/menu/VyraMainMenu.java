package gg.vyra.client.menu;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * VYRA-Hauptmenü: ersetzt den Vanilla-Titelbildschirm (Hook via Mixin auf
 * TitleScreen — siehe vyra-client.json). Alle Einträge sind verdrahtet;
 * Hintergrund-Animation ist abschaltbar und FPS-schonend (2D-Gradient +
 * max. 40 Partikel).
 */
public final class VyraMainMenu extends class_437 {
    private static boolean animation = true;
    private int ticks;
    private final float[] px = new float[40];
    private final float[] py = new float[40];
    private final float[] ps = new float[40];

    public VyraMainMenu() {
        super(class_2561.method_43470("VYRA Client"));
        java.util.Random r = new java.util.Random(1234);
        for (int i = 0; i < px.length; i++) {
            px[i] = r.nextFloat();
            py[i] = r.nextFloat();
            ps[i] = 0.2f + r.nextFloat() * 0.8f;
        }
    }

    public static void open() {
        class_310 mc = class_310.method_1551();
        if (mc != null) mc.method_1507(new VyraMainMenu());
    }

    public static void setAnimation(boolean on) { animation = on; }

    @Override
    protected void method_25426() {
        int cx = field_22789 / 2 - 100;
        int y = field_22790 / 2 - 80;
        int step = 26;
        method_37063(btn(cx, y, "Singleplayer", b -> single()));
        method_37063(btn(cx, y + step, "Multiplayer", b -> multi()));
        method_37063(btn(cx, y + step * 2, "HUD-Editor", b -> hudEditor()));
        method_37063(btn(cx, y + step * 3, "Performance", b -> perf()));
        method_37063(btn(cx, y + step * 4, "Mods (ModMenu, falls installiert)", b -> mods()));
        method_37063(btn(cx, y + step * 5, "Einstellungen", b -> settings()));
        method_37063(btn(cx, y + step * 6, "Animation: " + (animation ? "AN" : "AUS"), b -> {
            animation = !animation;
            b.method_25355(class_2561.method_43470("Animation: " + (animation ? "AN" : "AUS")));
        }));
    }

    private class_4185 btn(int x, int y, String label, class_4185.class_4241 a) {
        return class_4185.method_46430(class_2561.method_43470(label), a).method_46434(x, y, 200, 22).method_46431();
    }

    private void single() {
        class_310 mc = class_310.method_1551();
        mc.method_1507(new net.minecraft.class_526(this));
    }

    private void multi() {
        class_310 mc = class_310.method_1551();
        mc.method_1507(new net.minecraft.class_500(this));
    }

    private void hudEditor() {
        class_310 mc = class_310.method_1551();
        mc.method_1507(new HudEditorScreen(this));
    }

    private void perf() {
        class_310 mc = class_310.method_1551();
        mc.method_1507(new PerfScreen(this));
    }

    private void mods() {
        class_310 mc = class_310.method_1551();
        try {
            Class<?> cls = Class.forName("com.terraformersmc.modmenu.gui.ModsScreen");
            java.lang.reflect.Constructor<?> c = cls.getConstructor(class_437.class);
            mc.method_1507((class_437) c.newInstance(this));
        } catch (Exception e) {
            mc.method_1507(new InfoScreen(this, "ModMenu ist nicht installiert.",
                    "Installiere „Mod Menu“ über den VYRA-Launcher (Mods-Tab), um Mods ingame zu verwalten."));
        }
    }

    private void settings() {
        class_310 mc = class_310.method_1551();
        mc.method_1507(new net.minecraft.class_429(this, mc.field_1690));
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        ctx.method_25296(0, 0, field_22789, field_22790, 0xFF0A0A10, 0xFF1A1440);
        if (animation) {
            ticks++;
            for (int i = 0; i < px.length; i++) {
                py[i] -= 0.0006f * ps[i];
                if (py[i] < 0) py[i] = 1.0f;
                int x = (int) (px[i] * field_22789);
                int y = (int) (py[i] * field_22790);
                int a = (int) (40 + 30 * Math.sin(ticks * 0.02 + i));
                ctx.method_25294(x, y, x + 2, y + 2, (a << 24) | 0x8F7BFF);
            }
        }
        ctx.method_27534(field_22793, class_2561.method_43470("VYRA CLIENT"),
                field_22789 / 2, field_22790 / 2 - 120, 0xA78BFA);
        ctx.method_27534(field_22793,
                class_2561.method_43470("Your Minecraft. Your Performance. Your Rules."),
                field_22789 / 2, field_22790 / 2 - 104, 0x94A3B8);
        super.method_25394(ctx, mouseX, mouseY, delta);
    }
}
