package gg.vyra.client.menu;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** Einfacher Info-Dialog (z. B. fehlendes ModMenu wird erklärt statt Fake-Button). */
public final class InfoScreen extends class_437 {
    private final class_437 parent;
    private final String body;

    public InfoScreen(class_437 parent, String title, String body) {
        super(class_2561.method_43470(title));
        this.parent = parent;
        this.body = body;
    }

    @Override
    protected void method_25426() {
        method_37063(class_4185.method_46430(class_2561.method_43470("Zurück"), b -> method_25419())
                .method_46434(field_22789 / 2 - 100, field_22790 - 50, 200, 22).method_46431());
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        method_25420(ctx, mouseX, mouseY, delta);
        ctx.method_27534(field_22793, field_22785, field_22789 / 2, field_22790 / 2 - 30, 0xFFFFFF);
        ctx.method_27534(field_22793, class_2561.method_43470(body), field_22789 / 2, field_22790 / 2 - 10, 0x94A3B8);
        super.method_25394(ctx, mouseX, mouseY, delta);
    }

    @Override
    public void method_25419() {
        if (field_22787 != null) field_22787.method_1507(parent);
    }
}
