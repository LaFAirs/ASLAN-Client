package gg.vyra.client.util;

import gg.vyra.client.VyraClient;
import gg.vyra.client.core.PerformanceEngine;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** VYRA Quick Settings (Taste V): wichtigste Schalter ohne langes Navigieren. */
public final class QuickSettings extends class_437 {
    public QuickSettings() { super(class_2561.method_43470("VYRA Quick Settings")); }

    public static void open() {
        class_310 mc = class_310.method_1551();
        if (mc != null) mc.method_1507(new QuickSettings());
    }

    @Override
    protected void method_25426() {
        int y = 50;
        addRow(y, "HUD-Profil: PvP", b -> VyraClient.hud().setProfile("pvp")); y += 26;
        addRow(y, "HUD-Profil: Survival", b -> VyraClient.hud().setProfile("survival")); y += 26;
        addRow(y, "Perf: MAX FPS", b -> VyraClient.perf().apply(PerformanceEngine.Profile.MAX_FPS)); y += 26;
        addRow(y, "Perf: BALANCED", b -> VyraClient.perf().apply(PerformanceEngine.Profile.BALANCED)); y += 26;
        addRow(y, "Perf: QUALITY", b -> VyraClient.perf().apply(PerformanceEngine.Profile.QUALITY)); y += 26;
        addRow(y, "Screenshot", b -> ScreenshotStudio.take()); y += 26;
        method_37063(class_4185.method_46430(class_2561.method_43470("Schließen"), b -> method_25419())
                .method_46434(field_22789 / 2 - 100, y + 8, 200, 22).method_46431());
    }

    private void addRow(int y, String label, class_4185.class_4241 a) {
        method_37063(class_4185.method_46430(class_2561.method_43470(label), a)
                .method_46434(field_22789 / 2 - 100, y, 200, 22).method_46431());
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        method_25420(ctx, mouseX, mouseY, delta);
        ctx.method_27534(field_22793, field_22785, field_22789 / 2, 20, 0xFFFFFF);
        super.method_25394(ctx, mouseX, mouseY, delta);
    }
}
