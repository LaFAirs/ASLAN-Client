package gg.aslan.client.util;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import net.minecraft.class_310;

/** Screenshot-Studio: speichert Screenshots in aslan-screenshots/. */
public final class ScreenshotStudio {
    private ScreenshotStudio() {}

    public static File dir() {
        File d = new File(class_310.method_1551().field_1697, "aslan-screenshots");
        d.mkdirs();
        return d;
    }

    public static void take() {
        class_310 mc = class_310.method_1551();
        if (mc == null) return;
        try {
            String name = new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss").format(new Date());
            File out = new File(dir(), "aslan-" + name + ".png");
            net.minecraft.class_318.method_1663(mc.method_1522(), img -> {
                try {
                    img.method_4325(out);
                } catch (Exception ignored) {
                }
            });
        } catch (Exception ignored) {
        }
    }
}
