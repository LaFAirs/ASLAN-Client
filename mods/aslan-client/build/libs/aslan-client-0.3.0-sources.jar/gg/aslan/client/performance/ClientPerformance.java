package gg.aslan.client.performance;

import gg.aslan.client.core.PerformanceEngine;
import java.io.File;
import net.minecraft.class_310;

/**
 * Clientseitige Performance-Engine: wendet Profile auf echte
 * Minecraft-Optionen an (Sichtweiten, Grafik, Partikel, FPS-Limit, VSync).
 * Alles reversibel; Einstellungen werden in config/aslan-perf.json gespeichert.
 */
public final class ClientPerformance {
    private PerformanceEngine.Profile current = PerformanceEngine.Profile.BALANCED;

    public void applySavedOr(PerformanceEngine.Profile def) {
        PerformanceEngine.Profile p = load();
        apply(p == null ? def : p);
    }

    public void apply(PerformanceEngine.Profile p) {
        current = p;
        class_310 mc = class_310.method_1551();
        PerformanceEngine.Tier tier = estimateTier();
        PerformanceEngine.Settings s = PerformanceEngine.forProfile(p, tier);
        if (mc != null && mc.field_1690 != null) {
            try {
                mc.field_1690.method_42503().method_41748(s.renderDistance);
            } catch (Throwable ignored) {
            }
            try {
                mc.field_1690.method_42510().method_41748(s.simulationDistance);
            } catch (Throwable ignored) {
            }
            try {
                mc.field_1690.method_75317(s.fancyGraphics
                        ? net.minecraft.class_5365.field_25428
                        : net.minecraft.class_5365.field_25427);
            } catch (Throwable ignored) {
            }
            try {
                mc.field_1690.method_42475().method_41748(s.particles
                        ? net.minecraft.class_4066.field_18197
                        : net.minecraft.class_4066.field_18199);
            } catch (Throwable ignored) {
            }
            try {
                mc.field_1690.method_42524().method_41748(s.maxFps == 0 ? 260 : s.maxFps);
            } catch (Throwable ignored) {
            }
            try {
                mc.field_1690.method_42433().method_41748(s.vsync);
            } catch (Throwable ignored) {
            }
        }
        save(p);
    }

    public PerformanceEngine.Profile current() { return current; }

    private PerformanceEngine.Tier estimateTier() {
        int cores = Runtime.getRuntime().availableProcessors();
        long totalMB = Runtime.getRuntime().maxMemory() / 1048576L;
        // WICHTIG: kein GL11-Zugriff hier — beim Mod-Init existiert noch kein
        // OpenGL-Kontext; das crasht nativ (EXCEPTION_ACCESS_VIOLATION).
        // GPU-Schwaeche wird daher konservativ nicht angenommen (false).
        return PerformanceEngine.tier(cores, totalMB, false);
    }

    private File file() {
        return new File(class_310.method_1551().field_1697, "config/aslan-perf.json");
    }

    private void save(PerformanceEngine.Profile p) {
        try {
            File f = file();
            f.getParentFile().mkdirs();
            java.nio.file.Files.write(f.toPath(), ("{\"perf\":\"" + p.name() + "\"}").getBytes("UTF-8"));
        } catch (Exception ignored) {
        }
    }

    private PerformanceEngine.Profile load() {
        try {
            File f = file();
            if (!f.exists()) return null;
            String s = new String(java.nio.file.Files.readAllBytes(f.toPath()), "UTF-8");
            for (PerformanceEngine.Profile p : PerformanceEngine.Profile.values()) {
                if (s.contains(p.name())) return p;
            }
        } catch (Exception ignored) {
        }
        return null;
    }
}
