package gg.aslan.client.hud;

import gg.aslan.client.AslanClient;
import gg.aslan.client.core.HudLayout;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.minecraft.class_1293;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_640;

/**
 * HUD-Manager: rendert alle Widgets des aktiven Layouts, verwaltet Profile,
 * Klick-/Combo-Zähler und speichert Positionen pro Profil.
 */
public final class HudManager {
    private HudLayout active;
    private final HudLayout pvp = HudLayout.pvp();
    private final HudLayout survival = HudLayout.survival();
    private final List<Long> clicks = new ArrayList<Long>();
    private int combo;
    private long comboExpires;

    public HudManager(HudLayout initial) {
        this.active = initial;
    }

    public HudLayout active() { return active; }

    public void setProfile(String name) {
        if ("survival".equalsIgnoreCase(name) || "creative".equalsIgnoreCase(name)) active = survival;
        else active = pvp;
        saveToDisk();
    }

    public void registerClick() {
        long now = System.currentTimeMillis();
        clicks.add(now);
        while (!clicks.isEmpty() && now - clicks.get(0) > 1000) clicks.remove(0);
        combo++;
        comboExpires = now + 3000;
    }

    public void tick(class_310 mc) {
        long now = System.currentTimeMillis();
        while (!clicks.isEmpty() && now - clicks.get(0) > 1000) clicks.remove(0);
        if (now > comboExpires) combo = 0;
    }

    public void render(class_332 ctx, class_310 mc) {
        if (mc.field_1690.field_1842) return;
        int sw = ctx.method_51421();
        int sh = ctx.method_51443();
        for (HudLayout.Widget w : active.widgets) {
            if (!w.enabled) continue;
            int x = (int) (w.x * sw);
            int y = (int) (w.y * sh);
            int alpha = (int) (255 * clamp(w.opacity, 0.15, 1.0));
            int color = (0xFFFFFF & parseColor(w.color)) | (alpha << 24);
            String id = w.id;
            if ("fps".equals(id)) text(ctx, "FPS: " + mc.method_47599(), x, y, color);
            else if ("ping".equals(id)) text(ctx, "Ping: " + ping(mc) + " ms", x, y, color);
            else if ("coords".equals(id)) text(ctx, coords(mc), x, y, color);
            else if ("biome".equals(id)) text(ctx, biome(mc), x, y, color);
            else if ("clock".equals(id)) text(ctx, clock(), x, y, color);
            else if ("cps".equals(id)) text(ctx, "CPS: " + clicks.size(), x, y, color);
            else if ("combo".equals(id)) { if (combo > 1) text(ctx, "Combo x" + combo, x, y, color); }
            else if ("ram".equals(id)) text(ctx, ram(), x, y, color);
            else if ("keystrokes".equals(id)) renderKeystrokes(ctx, mc, x, y, color);
            else if ("armor".equals(id)) renderArmor(ctx, mc, x, y);
            else if ("potion".equals(id)) renderPotions(ctx, mc, x, y, color);
            else if ("crosshair".equals(id)) renderCrosshair(ctx, sw / 2, sh / 2, color);
            else if ("session".equals(id)) text(ctx, session(), x, y, color);
        }
    }

    private void text(class_332 ctx, String s, int x, int y, int color) {
        ctx.method_51439(class_310.method_1551().field_1772, class_2561.method_43470(s), x, y, color, true);
    }

    private int ping(class_310 mc) {
        try {
            if (mc.method_1562() == null) return 0;
            class_640 e = mc.method_1562().method_2871(mc.field_1724.method_5667());
            return e == null ? 0 : e.method_2959();
        } catch (Exception ex) {
            return 0;
        }
    }

    private String coords(class_310 mc) {
        class_2338 p = mc.field_1724.method_24515();
        String dir = mc.field_1724.method_5735().method_15434();
        return "XYZ: " + p.method_10263() + " / " + p.method_10264() + " / " + p.method_10260() + " (" + dir + ")";
    }

    private String biome(class_310 mc) {
        try {
            return "Biom: " + mc.field_1687.method_23753(mc.field_1724.method_24515()).method_40230().get().method_29177().method_12832();
        } catch (Exception ex) {
            return "Biom: —";
        }
    }

    private String clock() {
        java.util.Calendar c = java.util.Calendar.getInstance();
        return String.format("%02d:%02d", c.get(java.util.Calendar.HOUR_OF_DAY), c.get(java.util.Calendar.MINUTE));
    }

    private String ram() {
        Runtime rt = Runtime.getRuntime();
        long used = (rt.totalMemory() - rt.freeMemory()) / 1048576L;
        return "RAM: " + used + " MB";
    }

    private String session() {
        long mins = (System.currentTimeMillis() - AslanClient.SESSION_START) / 60000L;
        return "Session: " + mins + " min";
    }

    private void renderKeystrokes(class_332 ctx, class_310 mc, int x, int y, int color) {
        boolean w = mc.field_1690.field_1894.method_1434();
        boolean a = mc.field_1690.field_1913.method_1434();
        boolean s = mc.field_1690.field_1881.method_1434();
        boolean d = mc.field_1690.field_1849.method_1434();
        boolean sp = mc.field_1690.field_1903.method_1434();
        ctx.method_51439(mc.field_1772, class_2561.method_43470(key("W", w)), x + 16, y, color, true);
        ctx.method_51439(mc.field_1772, class_2561.method_43470(key("A", a)), x, y + 12, color, true);
        ctx.method_51439(mc.field_1772, class_2561.method_43470(key("S", s)), x + 16, y + 12, color, true);
        ctx.method_51439(mc.field_1772, class_2561.method_43470(key("D", d)), x + 32, y + 12, color, true);
        if (sp) ctx.method_51439(mc.field_1772, class_2561.method_43470("SPACE"), x, y + 24, color, true);
    }

    private String key(String k, boolean pressed) {
        return pressed ? "[" + k + "]" : " " + k + " ";
    }

    private void renderArmor(class_332 ctx, class_310 mc, int x, int y) {
        int dx = x;
        net.minecraft.class_1304[] slots = {
            net.minecraft.class_1304.field_6169,
            net.minecraft.class_1304.field_6174,
            net.minecraft.class_1304.field_6172,
            net.minecraft.class_1304.field_6166
        };
        for (int i = 0; i < slots.length; i++) {
            class_1799 stack = mc.field_1724.method_6118(slots[i]);
            if (stack == null || stack.method_7960()) continue;
            ctx.method_51427(stack, dx, y);
            int dmg = stack.method_7936() - stack.method_7919();
            ctx.method_51439(mc.field_1772, class_2561.method_43470(String.valueOf(dmg)), dx, y + 18, 0xFFFFFFFF, true);
            dx += 22;
        }
    }

    private void renderPotions(class_332 ctx, class_310 mc, int x, int y, int color) {
        Collection<class_1293> fx = mc.field_1724.method_6026();
        int dy = y;
        for (class_1293 e : fx) {
            String name;
            try {
                name = class_2561.method_43471(e.method_5586()).getString();
            } catch (Exception ex) {
                name = e.method_5586();
            }
            text(ctx, name + " " + (e.method_5578() + 1) + " (" + (e.method_5584() / 20) + "s)", x, dy, color);
            dy += 11;
        }
    }

    private void renderCrosshair(class_332 ctx, int x, int y, int color) {
        ctx.method_25294(x - 5, y, x + 6, y + 1, color);
        ctx.method_25294(x, y - 5, x + 1, y + 6, color);
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static int parseColor(String hex) {
        try {
            return Integer.parseInt(hex.replace("#", ""), 16);
        } catch (Exception e) {
            return 0xFFFFFF;
        }
    }

    private File file() {
        return new File(class_310.method_1551().field_1697, "config/aslan-hud.json");
    }

    public void saveToDisk() {
        try {
            File f = file();
            f.getParentFile().mkdirs();
            StringBuilder sb = new StringBuilder("{\"layout\":\"" + active.name + "\"}");
            java.nio.file.Files.write(f.toPath(), sb.toString().getBytes("UTF-8"));
        } catch (Exception ignored) {
        }
    }

    public void loadFromDisk() {
        try {
            File f = file();
            if (!f.exists()) return;
            String s = new String(java.nio.file.Files.readAllBytes(f.toPath()), "UTF-8");
            if (s.contains("survival")) active = survival;
            else active = pvp;
        } catch (Exception ignored) {
        }
    }
}
