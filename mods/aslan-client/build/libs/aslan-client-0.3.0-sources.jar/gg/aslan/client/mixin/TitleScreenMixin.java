package gg.aslan.client.mixin;

import gg.aslan.client.menu.AslanMainMenu;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Ersetzt den Vanilla-Titelbildschirm durch das ASLAN-Hauptmenü.
 * Einmalig pro Sitzung (Flag), damit Untermenüs normal funktionieren.
 */
@Mixin(class_442.class)
public abstract class TitleScreenMixin extends class_437 {
    protected TitleScreenMixin(net.minecraft.class_2561 title) {
        super(title);
    }

    private static boolean aslanShown = false;

    @Inject(method = "init", at = @At("HEAD"))
    private void aslan$replaceTitle(CallbackInfo ci) {
        if (aslanShown) return;
        aslanShown = true;
        class_310 mc = class_310.method_1551();
        if (mc != null) mc.method_1507(new AslanMainMenu());
    }
}
